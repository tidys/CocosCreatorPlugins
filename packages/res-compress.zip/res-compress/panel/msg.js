module.exports = {
    CompressImage: 'CompressImage',
    CompressAudio: 'CompressAudio',
}
