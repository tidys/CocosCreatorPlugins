module.exports={
    title:'res-compress',
};