module.exports={
    title:'资源压缩',
};